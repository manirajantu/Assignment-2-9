
import {Component} from "react";

class Apple extends Component {

    
    render(){
        return <div>
            <h1>Apple</h1>
        
            <h1>Well Done Apple !!!</h1>
        </div>
        }


}

export default Apple;

