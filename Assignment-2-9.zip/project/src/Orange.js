
import {Component} from "react";

class Orange extends Component {

    
    render(){
        return <div>
            <h1>Orange Page</h1>
        
            <h1>HI, I am Orange</h1>
        </div>
        }


}

export default Orange;

