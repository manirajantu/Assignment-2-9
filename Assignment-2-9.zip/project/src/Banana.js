
import {Component} from "react";

class Banana extends Component {

    
    render(){
        return <div>
            <h1>Banana Page</h1>
        
            <h1>This is a Banana page</h1>
        </div>
        }


}

export default Banana;

